package application;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class Controller implements Initializable {
	@FXML
	Button Mi1btn, Pl1btn, Mi2btn, Pl2btn, Pl3btn, Mi3btn, Resbtn, Cancbtn;
	@FXML
	Label Reslbl;
	@FXML
	TextArea txtRes;
	private String menu[] = {  "초코 쿠앤크 스무디", "블랙 밀크티 크러쉬", "커피 밀크티 크러쉬" };
	private int countm[] = new int[3];
	public int sum = 0;
	

    private model model = new model();

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {


    }
    public void menuAppend() {
        txtRes.setText("");
        for(int i = 0; i < 3; i++) {
            if(countm[i] != 0) txtRes.appendText(menu[i] + " " + countm[i] + "잔" + "\n");
        }
    }

    public void Pl1btnAction(ActionEvent event) {
        countm[0]++;
        menuAppend();
    }

    public void Pl2btnAction(ActionEvent event) {
        countm[1]++;
        menuAppend();
    }

    public void Pl3btnAction(ActionEvent event) {
        countm[2]++;
        menuAppend();
    }
 
    


    public void Mi1btnAction(ActionEvent event) {
        if(countm[0] > 0) countm[0]--;
        else countm[0] = 0;
        menuAppend();
    }
public void Mi2btnAction(ActionEvent event) {
        if(countm[1] > 0) countm[1]--;
        else countm[1] = 0;
        menuAppend();
    }

    public void Mi3btnAction(ActionEvent event) {
        if(countm[2] > 0) countm[2]--;
        else countm[2] = 0;
        menuAppend();
    }
   
    public void ResbtnAction(ActionEvent event) {
        DecimalFormat df = new DecimalFormat("#,###");
        sum = model.asum(countm);
        Reslbl.setText(df.format(sum));
    }
    public void CancbtnAction(ActionEvent event) {
        for(int i = 0; i < 3; i++) countm[i] = 0;
        txtRes.setText("");
        Reslbl.setText("0");
    }

}
	
