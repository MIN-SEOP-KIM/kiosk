package application;

public class model {
	public int asum(int[] ctm) {
		int sumt = 0;
		int m = 0;

		for (int i = 0; i < 3; i++) {
			if (i == 0) {
				m = 4500;
			}
			if (i == 1) {
				m = 4800;
			}
			if (i == 2) {
				m = 4800;
			}
		
			sumt = sumt + ctm[i] * m;
		}
		return sumt;
	}
}
